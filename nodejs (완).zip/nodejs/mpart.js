var M = {
    v:'v',
    f:function(){
      console.log(this.v);
    }
  }
   
  module.exports = M; // M 객체를 이 모듈 밖에서 사용할수 있도록 exports 하겠다는뜻