// var M = {
//   v:'v',
//   f:function(){
//     console.log(this.v);
//   }
// }

//M.f();
 
var part = require('./mpart.js');
part.f();