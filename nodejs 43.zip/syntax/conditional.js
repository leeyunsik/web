var args = process.argv;
console.log(args);

console.log('a');
console.log('');
if(args[2]==='1'){
    console.log('c1');
}else{
    console.log('c2');
}
console.log('d');