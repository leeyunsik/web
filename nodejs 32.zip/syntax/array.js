var arr = [4,3,5,6];
console.log(arr[1]);
console.log(arr[3]);
arr[2]= 3;
console.log(arr);
console.log(arr.length);
//arr.push('e');
console.log(arr);

var total = 0;
var i=0;
while(i<arr.length){
    total = total+arr[i]
;    i=i+1;
}
console.log(`total : ${total}`);